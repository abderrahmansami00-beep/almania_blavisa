/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  Briefcase, 
  FileCheck, 
  CheckCircle2, 
  ArrowRight, 
  Phone, 
  Mail, 
  MapPin, 
  Facebook, 
  Instagram, 
  Twitter,
  Menu,
  X,
  ChevronLeft,
  Users,
  Award,
  Globe,
  Sparkles,
  Zap,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { name: 'الرئيسية', href: '#home' },
    { name: 'خدماتنا', href: '#services' },
    { name: 'من نحن', href: '#about' },
    { name: 'الخطوات', href: '#prozess' },
    { name: 'اتصل بنا', href: '#kontakt' },
  ];

  const services = [
    {
      title: 'دورات اللغة',
      description: 'من المستوى المبتدئ إلى الاحترافي، نقدم برامج مكثفة ومرنة تناسب جدولك. دروس تفاعلية حية ومتوفرة مسائية وأسبوعية.',
      icon: <BookOpen className="w-10 h-10 text-brand-orange" />,
    },
    {
      title: 'تحضير الامتحانات',
      description: 'نحن متخصصون في تجهيزك لاجتياز امتحانات Goethe-Zertifikat، TestDaF، و DTZ. نقدم اختبارات تجريبية أسبوعية وتغذية راجعة فردية.',
      icon: <Award className="w-10 h-10 text-brand-orange" />,
    },
    {
      title: 'تدريب مهني & وظيفة',
      description: 'نربطك بشركات تبحث عن متدربين (Ausbildung) وموظفين في مجالات التمريض، تقنية المعلومات، الفنادق، والحرف. ندعمك في تحضير السيرة الذاتية والمقابلات.',
      icon: <Briefcase className="w-10 h-10 text-brand-orange" />,
    },
    {
      title: 'تأشيرة & معاملات',
      description: 'فريقنا القانوني يساعدك في استكمال أوراق التأشيرة، تقديم الطلبات للسفارة، معادلة الشهادات، ومرافقتك إلى دائرة الأجانب (Ausländerbehörde).',
      icon: <FileCheck className="w-10 h-10 text-brand-orange" />,
    },
  ];

  const steps = [
    { title: 'تقييم', desc: 'اختبار مجاني ومقابلة شخصية' },
    { title: 'دورة لغة', desc: 'مكثفة أو مرنة مع تركيز على الامتحان' },
    { title: 'شهادة', desc: 'امتحان Goethe / Telc داخل المعهد' },
    { title: 'تأشيرة', desc: 'مساعدة في الطلبات والمواعيد' },
    { title: 'تدريب/وظيفة', desc: 'توظيف وتوقيع العقد' },
  ];

  return (
    <div className="min-h-screen font-sans selection:bg-brand-orange selection:text-white noise-bg bg-brand-black text-white" dir="rtl">
      {/* Marquee Banner */}
      <div className="marquee-container">
        <div className="marquee-content">
          {[...Array(10)].map((_, i) => (
            <span key={i} className="mx-8 font-black uppercase text-xs tracking-[0.2em] inline-flex items-center gap-2">
              <Zap className="w-4 h-4 text-brand-black animate-pulse" /> تأشيرة ألمانيا بدون تعقيدات • <Sparkles className="w-4 h-4 text-brand-red animate-bounce" /> سجل الآن واستفد من خصم 20% • <Target className="w-4 h-4 text-brand-black" /> وظائف مضمونة للمتفوقين
            </span>
          ))}
        </div>
      </div>

      {/* Navigation */}
      <nav className="glass-nav">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-4"
          >
            <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center overflow-hidden brutal-border rotate-3 hover:rotate-0 transition-transform cursor-pointer">
              <img 
                src="https://storage.googleapis.com/aistudio-user-uploads/poxjmhcckjjtuoe7eydn7a/logo.png" 
                alt="Logo" 
                className="w-full h-full object-contain p-1"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="text-3xl font-black tracking-tighter text-white hidden lg:block">ALMANYA BLA VISA</span>
          </motion.div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link, i) => (
              <motion.a 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                key={link.name} 
                href={link.href} 
                className="text-slate-400 hover:text-brand-orange font-black transition-colors uppercase text-xs tracking-widest"
              >
                {link.name}
              </motion.a>
            ))}
            <motion.a 
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="#kontakt" 
              className="btn-primary py-2 px-6 text-[10px]"
            >
              استشارة مجانية
            </motion.a>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-white p-2 border-2 border-brand-orange/30 rounded-lg" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              className="fixed inset-0 z-40 bg-brand-black md:hidden"
            >
              <div className="flex flex-col p-12 gap-8 h-full justify-center items-center text-center">
                <button className="absolute top-6 right-6 text-white" onClick={() => setIsMenuOpen(false)}><X className="w-10 h-10" /></button>
                {navLinks.map((link, i) => (
                  <motion.a 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    key={link.name} 
                    href={link.href} 
                    className="text-5xl font-black text-white hover:text-brand-orange transition-colors uppercase italic"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {link.name}
                  </motion.a>
                ))}
                <a href="#kontakt" className="btn-primary w-full max-w-xs text-xl py-6" onClick={() => setIsMenuOpen(false)}>استشارة مجانية</a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative overflow-hidden pt-40 pb-32 lg:pt-64 lg:pb-48 bg-brand-black">
        <div className="absolute top-0 right-0 w-full h-full pointer-events-none -z-10">
          <div className="absolute top-1/4 right-1/4 w-[600px] h-[600px] bg-brand-orange/10 rounded-full blur-[120px] animate-pulse-slow"></div>
          <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-brand-red/10 rounded-full blur-[100px] animate-pulse-slow delay-1000"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: 100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-4 bg-brand-orange text-brand-black px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.3em] mb-10 brutal-border"
            >
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center overflow-hidden border border-brand-black/10">
                <img 
                  src="https://storage.googleapis.com/aistudio-user-uploads/poxjmhcckjjtuoe7eydn7a/logo.png" 
                  alt="Logo" 
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="flex items-center gap-2">
                <Sparkles className="w-3 h-3 text-brand-black" /> مستقبلك يبدأ هنا
              </span>
            </motion.div>
            <h1 className="text-7xl md:text-9xl font-black text-white leading-[0.85] mb-10 uppercase italic">
              إتقان اللغة <br />
              <span className="gradient-text">الألمانية</span> <br />
              بلا حدود
            </h1>
            <p className="text-2xl text-slate-400 max-w-xl mb-12 leading-relaxed font-bold border-r-4 border-brand-orange pr-6">
              طريقك إلى المستقبل في ألمانيا – معهد لغوي مع دعم متكامل: تحضير للامتحانات، تأشيرة، توفير فرص تدريب وتوظيف.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center gap-6 mb-16">
              <motion.a 
                whileHover={{ scale: 1.05, rotate: -2 }}
                whileTap={{ scale: 0.95 }}
                href="#kontakt" 
                className="btn-primary w-full sm:w-auto flex items-center justify-center gap-3 group text-lg py-6 px-12 shadow-[8px_8px_0px_0px_rgba(242,125,38,0.3)]"
              >
                استشارة مجانية <ChevronLeft className="w-6 h-6 transition-transform group-hover:-translate-x-2" />
              </motion.a>
              <motion.a 
                whileHover={{ scale: 1.05, rotate: 2 }}
                whileTap={{ scale: 0.95 }}
                href="#services" 
                className="btn-secondary w-full sm:w-auto text-lg py-6 px-12"
              >
                استكشف برامجنا
              </motion.a>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, rotate: 10, scale: 0.9 }}
            whileInView={{ opacity: 1, rotate: 0, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, type: "spring" }}
            className="relative"
          >
            <motion.div 
              animate={{ rotate: [12, 15, 12] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-12 -right-12 w-48 h-48 bg-brand-red rounded-full flex items-center justify-center text-white font-black text-center leading-tight z-20 brutal-border text-2xl uppercase italic"
            >
              سجل <br /> الآن
            </motion.div>
            <div className="relative z-10 group">
              <div className="absolute -inset-4 bg-brand-orange rounded-3xl -rotate-3 transition-transform group-hover:rotate-0"></div>
              <img 
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=2071" 
                alt="Students" 
                className="rounded-3xl brutal-border relative z-10 grayscale hover:grayscale-0 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
        </div>

        <div className="max-w-7xl mx-auto px-6 mt-32">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { val: '98%', label: 'نسبة النجاح', color: 'text-brand-orange' },
              { val: '+5', label: 'سنوات خبرة', color: 'text-brand-red' },
              { val: '+20', label: 'شركة شريكة', color: 'text-white' },
              { val: '+500', label: 'خريج سنوياً', color: 'text-brand-orange' },
            ].map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="brutal-card text-center group overflow-hidden relative"
              >
                <div className="absolute top-0 left-0 w-full h-1 bg-brand-orange scale-x-0 group-hover:scale-x-100 transition-transform origin-right"></div>
                <div className={`text-6xl font-black ${stat.color} mb-2 italic`}>{stat.val}</div>
                <div className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em]">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-padding bg-brand-dark text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-brand-orange via-transparent to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-32 gap-12">
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="max-w-3xl"
            >
              <h2 className="text-6xl md:text-9xl font-black mb-8 uppercase leading-none italic">حلول <br /> <span className="text-brand-orange">شاملة</span></h2>
              <p className="text-slate-400 text-2xl font-bold leading-relaxed max-w-xl">
                تعليم اللغة + المعاملات الرسمية + المسار المهني – نرافقك من أول كلمة ألمانية حتى عقد العمل.
              </p>
            </motion.div>
            <motion.a 
              whileHover={{ x: -10 }}
              href="#kontakt" 
              className="text-brand-orange font-black uppercase tracking-[0.4em] text-sm flex items-center gap-4 group"
            >
              جميع الخدمات <ArrowRight className="w-8 h-8 rotate-180 group-hover:scale-125 transition-transform" />
            </motion.a>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -15, scale: 1.02 }}
                className="bg-brand-gray p-12 border-2 border-white/5 transition-all hover:bg-white/5 hover:border-brand-orange group relative overflow-hidden"
              >
                <div className="absolute -right-8 -bottom-8 opacity-5 group-hover:opacity-10 transition-opacity">
                  {React.cloneElement(service.icon as React.ReactElement, { className: "w-40 h-40" })}
                </div>
                <div className="mb-10 p-5 bg-brand-orange/10 w-fit rounded-2xl group-hover:bg-brand-orange transition-colors brutal-border">
                  {React.cloneElement(service.icon as React.ReactElement, { className: "w-12 h-12 text-brand-orange group-hover:text-white transition-colors" })}
                </div>
                <h3 className="text-3xl font-black mb-6 uppercase italic">{service.title}</h3>
                <p className="text-slate-400 text-base leading-relaxed font-bold">
                  {service.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="section-padding bg-brand-black relative">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-32 items-center">
          <motion.div 
            initial={{ opacity: 0, x: 100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative group"
          >
            <div className="absolute -inset-6 bg-brand-red/10 rounded-3xl rotate-3 transition-transform group-hover:rotate-0"></div>
            <img 
              src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=2070" 
              alt="Team working" 
              className="rounded-3xl shadow-2xl relative z-10 brutal-border grayscale hover:grayscale-0 transition-all duration-1000"
              referrerPolicy="no-referrer"
            />
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 5, repeat: Infinity }}
              className="absolute -bottom-12 -left-12 bg-brand-gray text-white p-12 rounded-2xl shadow-2xl z-20 brutal-border hidden md:block"
            >
              <div className="text-7xl font-black mb-2 text-brand-orange italic">5+</div>
              <div className="text-[10px] font-black uppercase tracking-[0.4em] opacity-60">سنوات من التميز</div>
            </motion.div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="w-24 h-3 bg-brand-orange mb-10"></div>
            <h2 className="text-6xl md:text-8xl font-black text-white mb-10 uppercase leading-[0.85] italic">أكثر من <br /> <span className="text-brand-red">معهد لغوي</span></h2>
            <p className="text-2xl text-slate-400 mb-12 leading-relaxed font-bold">
              منذ أكثر من 5 سنوات نساعد الأشخاص للوصول إلى ألمانيا. فريقنا مكون من مدرسين natives، مستشارين معتمدين ومتدربين سابقين. نعرف تعقيدات الدوائر الرسمية ونساعدك لتحقق أقصى فرصك.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-4 mb-16">
              {[
                'دورات مهنية (B2/C1)',
                'تدريب فردي على التقديم',
                'شراكة مع 20+ شركة',
                'مرافقة إلى السفارة'
              ].map((item, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ x: 10 }}
                  className="flex items-center gap-4 p-6 bg-brand-gray rounded-2xl border-2 border-brand-orange/20 font-black text-xs uppercase italic"
                >
                  <CheckCircle2 className="text-brand-orange w-6 h-6" />
                  {item}
                </motion.div>
              ))}
            </div>

            <div className="flex items-center gap-8">
              <div className="flex -space-x-6 space-x-reverse">
                {[1,2,3,4,5].map(i => (
                  <motion.img 
                    key={i}
                    whileHover={{ y: -10, zIndex: 50 }}
                    src={`https://i.pravatar.cc/100?img=${i+30}`} 
                    className="w-16 h-16 rounded-full border-4 border-brand-black shadow-xl cursor-pointer"
                    referrerPolicy="no-referrer"
                  />
                ))}
              </div>
              <div className="text-sm text-slate-400 font-bold">
                <span className="text-white font-black text-2xl italic">انضم إلى +2000</span> طالب ناجح
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Process Section */}
      <section id="prozess" className="section-padding bg-brand-orange text-brand-black overflow-hidden relative">
        <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none">
          <Globe className="w-[1000px] h-[1000px] absolute -top-64 -right-64 animate-pulse-slow text-brand-black" />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-32">
            <h2 className="text-7xl md:text-[10rem] font-black mb-8 uppercase leading-none italic text-brand-black">خريطة <br /> الطريق</h2>
            <p className="text-2xl font-black opacity-90 max-w-2xl mx-auto uppercase tracking-widest">
              من أول درس حتى بداية العمل – نبقى معك خطوة بخطوة.
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-16 relative">
            {steps.map((step, index) => (
              <motion.div 
                key={index} 
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, type: "spring" }}
                className="relative z-10 text-center group"
              >
                <div className="w-32 h-32 bg-brand-black text-white rounded-[2rem] flex items-center justify-center text-5xl font-black mx-auto mb-10 shadow-2xl rotate-6 group-hover:rotate-0 transition-transform brutal-border cursor-pointer">
                  {index + 1}
                </div>
                <h3 className="text-3xl font-black mb-4 uppercase italic">{step.title}</h3>
                <p className="text-base font-bold opacity-80 leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-32 text-center">
            <motion.a 
              whileHover={{ scale: 1.1, rotate: -2 }}
              whileTap={{ scale: 0.9 }}
              href="#kontakt" 
              className="inline-flex items-center gap-6 bg-brand-black text-white px-16 py-8 rounded-3xl font-black text-2xl hover:bg-brand-red transition-all shadow-[12px_12px_0px_0px_rgba(0,0,0,0.3)] brutal-border uppercase tracking-[0.2em] italic"
            >
              ابدأ رحلتك الآن <ChevronLeft className="w-10 h-10" />
            </motion.a>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="kontakt" className="section-padding bg-brand-black">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-32">
          <motion.div
            initial={{ opacity: 0, x: 100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-7xl md:text-9xl font-black text-white mb-12 uppercase leading-none italic">هيا بنا <br /> <span className="text-brand-orange">نبدأ</span></h2>
            <p className="text-2xl text-slate-400 mb-16 font-bold leading-relaxed">
              احجز استشارة مجانية – عبر الإنترنت أو في مقرنا. نحن هنا لمساعدتك في كل خطوة.
            </p>

            <div className="space-y-12">
              {[
                { 
                  icon: <MapPin />, 
                  title: 'العنوان', 
                  content: 'ALMANIABLAVISA, Atlas en face de concentrix, Bureaux Yassine, avenue moulay rachide 5eme étage bureau 32, Fez, Morocco, 30000', 
                  color: 'bg-brand-orange/10 text-brand-orange' 
                },
                { icon: <Phone />, title: 'الهاتف', content: '+49 1525 7482417', color: 'bg-brand-red/10 text-brand-red' },
                { icon: <Mail />, title: 'البريد الإلكتروني', content: 'info-alm@almaniablavisa.de', color: 'bg-brand-orange/10 text-brand-orange' },
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  whileHover={{ x: 20 }}
                  className="flex items-start gap-8 group cursor-pointer"
                >
                  <div className={`w-20 h-20 ${item.color} rounded-3xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform brutal-border`}>
                    {React.cloneElement(item.icon as React.ReactElement, { className: "w-10 h-10" })}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-2xl font-black text-white uppercase mb-2 italic">{item.title}</h4>
                    <p className="text-xl text-slate-400 font-black tracking-tight leading-relaxed" dir={item.title === 'الهاتف' ? 'ltr' : 'rtl'}>{item.content}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="brutal-card bg-brand-gray p-12 md:p-16"
          >
            <form className="space-y-10" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-10">
                <div className="space-y-4">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-[0.4em]">الاسم الكامل</label>
                  <input type="text" className="w-full px-8 py-5 rounded-2xl border-4 border-brand-orange/20 bg-brand-black text-white focus:ring-8 focus:ring-brand-orange/20 outline-none transition-all font-black text-lg placeholder:opacity-30" placeholder="أحمد محمد" />
                </div>
                <div className="space-y-4">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-[0.4em]">رقم الهاتف</label>
                  <input type="tel" className="w-full px-8 py-5 rounded-2xl border-4 border-brand-orange/20 bg-brand-black text-white focus:ring-8 focus:ring-brand-orange/20 outline-none transition-all font-black text-lg placeholder:opacity-30" placeholder="+212 ..." />
                </div>
              </div>
              <div className="space-y-4">
                <label className="text-xs font-black text-slate-400 uppercase tracking-[0.4em]">المستوى اللغوي الحالي</label>
                <div className="relative">
                  <select className="w-full px-8 py-5 rounded-2xl border-4 border-brand-orange/20 bg-brand-black text-white focus:ring-8 focus:ring-brand-orange/20 outline-none transition-all font-black text-lg appearance-none cursor-pointer">
                    <option>مبتدئ (A1/A2)</option>
                    <option>متوسط (B1/B2)</option>
                    <option>متقدم (C1/C2)</option>
                    <option>لا أعرف</option>
                  </select>
                  <ChevronLeft className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 -rotate-90 pointer-events-none text-brand-orange" />
                </div>
              </div>
              <div className="space-y-4">
                <label className="text-xs font-black text-slate-400 uppercase tracking-[0.4em]">الرسالة</label>
                <textarea className="w-full px-8 py-5 rounded-2xl border-4 border-brand-orange/20 bg-brand-black text-white focus:ring-8 focus:ring-brand-orange/20 outline-none transition-all h-48 font-black text-lg placeholder:opacity-30" placeholder="كيف يمكننا مساعدتك؟"></textarea>
              </div>
              <motion.button 
                whileHover={{ scale: 1.02, y: -5 }}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full py-8 text-2xl shadow-[10px_10px_0px_0px_rgba(242,125,38,0.2)] hover:shadow-none hover:translate-x-2 hover:translate-y-2 italic"
              >
                إرسال الطلب الآن
              </motion.button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-brand-black text-white pt-48 pb-20 relative overflow-hidden">
        <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-brand-orange via-brand-red to-brand-orange"></div>
        
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-24 mb-32">
            <div className="col-span-1 lg:col-span-1">
              <div className="flex items-center gap-6 mb-12">
                <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center overflow-hidden brutal-border rotate-6 hover:rotate-0 transition-transform">
                  <img 
                    src="https://storage.googleapis.com/aistudio-user-uploads/poxjmhcckjjtuoe7eydn7a/logo.png" 
                    alt="Logo" 
                    className="w-full h-full object-contain p-2"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="text-5xl font-black tracking-tighter uppercase italic text-white">ALMANYA BLA VISA</span>
              </div>
              <p className="text-slate-400 text-lg leading-relaxed font-bold italic">
                جسرك المتكامل للتدريب والوظيفة في ألمانيا. نحن نؤمن بأن اللغة هي المفتاح الأول لنجاحك المهني.
              </p>
            </div>

            <div>
              <h4 className="font-black mb-10 uppercase tracking-[0.3em] text-brand-orange italic text-xl">الخدمات</h4>
              <ul className="space-y-6 text-slate-400 text-lg font-black uppercase">
                <li><a href="#" className="hover:text-brand-orange transition-colors hover:italic">دورات لغة</a></li>
                <li><a href="#" className="hover:text-brand-orange transition-colors hover:italic">تحضير امتحانات</a></li>
                <li><a href="#" className="hover:text-brand-orange transition-colors hover:italic">تدريب مهني</a></li>
                <li><a href="#" className="hover:text-brand-orange transition-colors hover:italic">خدمات التأشيرة</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-black mb-10 uppercase tracking-[0.3em] text-brand-red italic text-xl">قانوني</h4>
              <ul className="space-y-6 text-slate-400 text-lg font-black uppercase">
                <li><a href="#" className="hover:text-brand-red transition-colors hover:italic">بيانات النشر</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors hover:italic">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors hover:italic">الشروط والأحكام</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-black mb-10 uppercase tracking-[0.3em] text-white italic text-xl">تابعنا</h4>
              <div className="flex gap-6">
                {[Facebook, Instagram, Twitter].map((Icon, i) => (
                  <motion.a 
                    key={i}
                    whileHover={{ scale: 1.2, rotate: i % 2 === 0 ? 10 : -10 }}
                    href="#" 
                    className="w-16 h-16 bg-brand-gray rounded-3xl flex items-center justify-center hover:bg-brand-orange transition-all border-2 border-white/10"
                  >
                    <Icon className="w-8 h-8" />
                  </motion.a>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-16 border-t-2 border-white/10 text-center text-slate-500 text-xs font-black uppercase tracking-[0.5em] italic">
            <p>© ٢٠٢٦ ALMANYA BLA VISA – تعلم الألمانية والوصول للوظيفة. جميع الحقوق محفوظة.</p>
            <p className="mt-4 text-[10px] opacity-50">ALMANIABLAVISA, Atlas en face de concentrix, Bureaux Yassine, avenue moulay rachide 5eme étage bureau 32, Fez, Morocco, 30000</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
